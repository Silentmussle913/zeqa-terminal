import open from 'open';

// Get the version, operating system, and preview option from command-line arguments
const [,, version, os, preview] = process.argv;

// Validate the input
if (!version) {
    console.error('Error: Missing version argument.');
    console.error('Usage: node getServerSoftware <version> <operating-system> [<preview>]');
    console.error('Operating System: "win" for Windows, "linux" for Linux.');
    console.error('Preview: Leave empty for normal download or type "preview" for preview version.');
    process.exit(1);
}

// Set the base URL based on the operating system and preview option
let baseUrl = '';
if (os === 'win') {
    baseUrl = preview === 'preview'
        ? `https://www.minecraft.net/bedrockdedicatedserver/bin-win-preview/bedrock-server-${version}.zip`
        : `https://www.minecraft.net/bedrockdedicatedserver/bin-win/bedrock-server-${version}.zip`;
} else if (os === 'linux') {
    baseUrl = preview === 'preview'
        ? `https://www.minecraft.net/bedrockdedicatedserver/bin-linux-preview/bedrock-server-${version}.zip`
        : `https://www.minecraft.net/bedrockdedicatedserver/bin-linux/bedrock-server-${version}.zip`;
} else {
    console.error('Error: Invalid operating system. Use "win" for Windows or "linux" for Linux.');
    process.exit(1);
}

/**
 * Function to open the download URL in the default browser.
 * @param {string} url - The URL to open.
 */
function openDownloadUrl(url) {
    console.log(`\nGenerated Download URL: ${url}`);
    
    // Open the URL in the default browser
    open(url);

    // Display a message in the console
    console.log(`\nA new tab has been opened in your default browser with the download link for Bedrock Server version ${version}.\n`);
}

// Call the function with the generated URL
openDownloadUrl(baseUrl);
